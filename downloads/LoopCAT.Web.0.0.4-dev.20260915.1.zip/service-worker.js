const APP_VERSION = "0.0.4-dev.20260915.1";
// Bump when a cached UI asset changes so installed PWAs refresh their shell.
const STATIC_ASSET_REVISION = "2026-09-13-resources-recovery";
const CACHE_PREFIX = "loopcat-offline-";
const CACHE_NAME = `${CACHE_PREFIX}${APP_VERSION}-${STATIC_ASSET_REVISION}`;

importScripts("./config/production-assets.js");
const CORE_ASSETS = Object.freeze(["./", ...self.LoopCATProductionAssets.offlineAssets.map((asset) => `./${asset}`)]);

const CORE_ASSET_URLS = new Set(CORE_ASSETS.map((asset) => new URL(asset, self.location.href).href));
const INDEX_URL = new URL("./index.html", self.location.href).href;

async function cacheCoreAssets(cache) {
  const failedAssets = [];
  await Promise.all(
    CORE_ASSETS.map(async (asset) => {
      try {
        await cache.add(asset);
      } catch (error) {
        failedAssets.push(`${asset}: ${error?.message || error}`);
        console.warn("Offline shell asset cache failed.", asset, error);
      }
    })
  );
  if (failedAssets.length) {
    throw new Error(`Offline shell core asset cache failed: ${failedAssets.join("; ")}`);
  }
}

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cacheCoreAssets(cache)));
});

self.addEventListener("message", (event) => {
  if (event.data?.type === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE_NAME).map((key) => caches.delete(key))
        )
      )
      .then(() => self.clients.claim())
  );
});

function shouldHandle(request) {
  const url = new URL(request.url);
  return request.method === "GET" && url.origin === self.location.origin;
}

function normalizedRequestUrl(request) {
  const url = new URL(request.url);
  url.hash = "";
  return url.href;
}

function isCoreAssetRequest(request) {
  return CORE_ASSET_URLS.has(normalizedRequestUrl(request));
}

function isNavigationRequest(request) {
  const accept = request.headers.get("accept") || "";
  return request.mode === "navigate" || accept.includes("text/html");
}

async function cachedIndex() {
  const cache = await caches.open(CACHE_NAME);
  return cache.match(INDEX_URL);
}

self.addEventListener("fetch", (event) => {
  if (!shouldHandle(event.request)) return;
  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(event.request);
      if (cached) return cached;
      const navigation = isNavigationRequest(event.request);
      try {
        const response = await fetch(event.request);
        if (!response || response.status !== 200 || response.type === "opaque") {
          if (navigation) return (await cachedIndex()) || response;
          return response;
        }
        if (isCoreAssetRequest(event.request)) {
          const copy = response.clone();
          event.waitUntil(
            cache.put(event.request, copy).catch((error) => {
              console.warn("Offline shell runtime cache write failed.", event.request.url, error);
            })
          );
        }
        return response;
      } catch (error) {
        if (navigation) {
          const fallback = await cachedIndex();
          if (fallback) return fallback;
        }
        throw error;
      }
    })()
  );
});
