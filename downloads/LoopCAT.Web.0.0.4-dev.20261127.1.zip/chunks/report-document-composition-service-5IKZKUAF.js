import{b as j}from"./chunk-LO5BYPVF.js";var P=`:root { color-scheme: light; --canvas: #f7f7f2; --paper: white; --subtle: #f2f5f2; --text: #183932; --muted: #536860; --line: #d7dfd8; --accent: #086959; font: 1rem/1.5 system-ui, sans-serif; color: var(--text); background: var(--canvas); }
* { box-sizing: border-box; }
body { margin: 0; padding: clamp(.5rem, 3vw, 2rem); overflow-wrap: anywhere; }
main { max-width: 64rem; margin: auto; background: var(--paper); border: 1px solid var(--line); border-radius: .75rem; }
header, section, footer { padding: clamp(1rem, 3vw, 2rem); }
header { background: #133e39; color: white; border-radius: .75rem .75rem 0 0; }
header .muted { color: #daebe4; }
h1, h2, p { margin: 0 0 .5rem; }
h1 { font-size: clamp(1.5rem, 3vw, 2.125rem); line-height: 1.2; }
h2 { font-size: 1.2rem; }
section, footer { border-block-start: 1px solid var(--line); }
.meta, .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 9rem), 1fr)); gap: .625rem; }
.card { border: 1px solid var(--line); border-radius: .625rem; padding: .875rem; background: var(--subtle); }
.card strong { display: block; font-size: 1.35rem; color: var(--accent); font-variant-numeric: tabular-nums; }
.card span, .muted, footer { color: var(--muted); }
table { width: 100%; border-collapse: collapse; font-size: .875rem; }
th, td { border-block-end: 1px solid var(--line); padding: .5rem; text-align: start; vertical-align: top; }
th { background: var(--subtle); } ul { margin: 0; padding-inline-start: 1.25rem; }
footer { font-size: .8125rem; }
@media screen and (prefers-color-scheme: dark) { :root { color-scheme: dark; --canvas: #15211e; --paper: #1c2c27; --subtle: #23362f; --text: #edf4eb; --muted: #b5c6bb; --line: #3c5046; --accent: #94e5c9; } }
@media (max-width: 36rem) { section:has(table) { overflow-x: auto; } th, td { padding: .35rem; } }
@media print { :root { --canvas: white; } body, main { padding: 0; background: white; border: 0; } header, header .muted { color: var(--text); background: white; } h2 { break-after: avoid; } tr, .card { break-inside: avoid; } }`;function U(m){let e=m?.localization,r=m?.presentation,s=m?.escapeHtml,q=m?.redactSensitiveText,b=m?.defaultQualityProfile,k=m?.sanitizeValidationReportForDisplay,w=m?.languagePairDisplay,f=m?.formatDateTime,u=m?.qualityLabel,N=m?.qualityCategoryName,T=m?.qualityRiskLevelLabel;if(typeof e?.source!="function"||typeof e?.sourceHtml!="function"||typeof e?.locale!="function"||typeof e?.direction!="function"||typeof r?.countTableHtml!="function"||typeof r?.listHtml!="function"||typeof r?.qaChecksTableHtml!="function"||typeof r?.qualityCategoryCountTableHtml!="function"||typeof r?.safeLabel!="function"||typeof s!="function"||typeof q!="function"||typeof b!="function"||typeof k!="function"||typeof w!="function"||typeof f!="function"||typeof u!="function"||typeof N!="function"||typeof T!="function")throw new TypeError("ReportDocumentCompositionService requires localization, presentation, escaping, redaction, quality, validation, language, and date boundaries.");let p=e.source,A=t=>t==="clear"?p("No risk"):T(t),Q=t=>p({"needs-review":"Needs review",reviewed:"Reviewed",blocked:"Blocked"}[t]||t),I=t=>p({errors:"Errors",risk:"Risks",warnings:"Warnings",notes:"Notes"}[t]);function L(t){if(/^en(?:-|$)/i.test(e.locale()))return t;let a=/^(\d+) (empty target|non-empty unconfirmed target) segments? (will (?:export source text|remain empty in the exported interchange file|be reported as untranslated|export as written))\.$/.exec(t);return a?p(`{value1} ${a[2]} segment(s) ${a[3]}.`,{value1:a[1]}):t}function z(t){if(/^en(?:-|$)/i.test(e.locale()))return t;if(t==="No major unresolved quality signals.")return p("No major post-editing drivers.");let a=/^(\d+) (high or critical risk segments?|QA issues?|untranslated segments?)\.$/.exec(t);return a?`${p({"high or critical risk segment":"High or critical risk segments","QA issue":"QA issues","untranslated segment":"Untranslated"}[a[2].replace(/s$/,"")])}: ${a[1]}`:t}function E(t,a={}){let n=!!a.anonymized,c=t.project,l=t.analysis.totals,d=t.analysis.ai||{drafts:0,suggestionSegments:0,suggestions:0,reviewRisk:0,highRisk:0,risk:{}},h=t.qualityPassport||{},g=b(h.profile||c.qualityProfile),$=h.riskQueue||{totalRiskItems:0,highRiskCount:0,averageScore:0,byLevel:{}},H=h.postEditingEffort||{label:"No segments",score:0,drivers:[]},i=k(t.validation)||{errors:[],risky:[],warnings:[],preserved:[],simplified:[],skipped:[],ok:!0},v=n?t.analysis.files.map((o,C)=>({...o,name:`File ${C+1}`})):t.analysis.files.map(o=>({...o,name:r.safeLabel(o.name,"File")})),y=n?t.resources:{...t.resources,mainTm:r.safeLabel(t.resources.mainTm,"None"),tmNames:(t.resources.tmNames||[]).map(o=>r.safeLabel(o)).filter(Boolean),tbNames:(t.resources.tbNames||[]).map(o=>r.safeLabel(o)).filter(Boolean)},D={errors:i.errors.length,risk:i.risky.length,warnings:i.warnings.length,notes:i.preserved.length+i.simplified.length+i.skipped.length},R=(o,C)=>o.map(F=>`<tr>${C(F).join("")}</tr>`).join(""),S=n?e.source("Anonymized project"):r.safeLabel(c.name,e.source("Project")),x=n?e.source("LoopCAT Anonymized Project Report"):e.source("LoopCAT Project Report");return`<!doctype html>
<html lang="${s(e.locale())}" dir="${s(e.direction())}">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; script-src 'none'; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'">
    <title>${s(S)} - ${s(x)}</title>
    <style>${P}</style>
  </head>
  <body>
    <main>
      <header>
        <h1>${s(x)}</h1>
        <p>${s(S)} - ${s(w(c.sourceLang,c.targetLang))}</p>
        <p class="muted">${e.sourceHtml("Generated {date}",{date:f(t.generatedAt)})}</p>
      </header>
      <section>
        <h2>${e.sourceHtml("Project")}</h2>
        <div class="meta">
          <div class="card"><strong>${s(q(c.domain||"").trim()||e.source("Not set"))}</strong><span>${e.sourceHtml("Domain")}</span></div>
          <div class="card"><strong>${l.confirmedPercent}%</strong><span>${e.sourceHtml("Confirmed")}</span></div>
          <div class="card"><strong>${l.words}</strong><span>${e.sourceHtml("Source words")}</span></div>
          <div class="card"><strong>${t.qaChecks.length}</strong><span>${e.sourceHtml("QA issues")}</span></div>
        </div>
      </section>
      <section>
        <h2>${e.sourceHtml("Progress")}</h2>
        <div class="cards">
          <div class="card"><strong>${l.files}</strong><span>${e.sourceHtml("Files")}</span></div>
          <div class="card"><strong>${l.segments}</strong><span>${e.sourceHtml("Segments")}</span></div>
          <div class="card"><strong>${l.confirmed}</strong><span>${e.sourceHtml("Confirmed")}</span></div>
          <div class="card"><strong>${l.untranslated}</strong><span>${e.sourceHtml("Untranslated")}</span></div>
          <div class="card"><strong>${l.repetitions}</strong><span>${e.sourceHtml("Repetitions")}</span></div>
          <div class="card"><strong>${l.comments}</strong><span>${e.sourceHtml("Review notes")}</span></div>
          <div class="card"><strong>${t.revisionCount}</strong><span>${e.sourceHtml("Target revisions")}</span></div>
        </div>
      </section>
      <section>
        <h2>${e.sourceHtml("Quality Passport")}</h2>
        <div class="cards">
          <div class="card"><strong>${h.confidenceScore??0}</strong><span>${e.sourceHtml("Quality score")}</span></div>
          <div class="card"><strong>${s(e.source(H.label))}</strong><span>${e.sourceHtml("Post-editing effort")}</span></div>
          <div class="card"><strong>${$.totalRiskItems}</strong><span>${e.sourceHtml("Risk items")}</span></div>
          <div class="card"><strong>${$.highRiskCount}</strong><span>${e.sourceHtml("High risk")}</span></div>
        </div>
        <table>
          <tbody>
            <tr><th>${e.sourceHtml("Standard")}</th><td>${s(u(g.standard))}</td></tr>
            <tr><th>${e.sourceHtml("Review depth")}</th><td>${s(u(g.reviewDepth))}</td></tr>
            <tr><th>${e.sourceHtml("Risk tolerance")}</th><td>${s(u(g.riskTolerance))}</td></tr>
            <tr><th>${e.sourceHtml("Terminology")}</th><td>${s(u(g.terminologyStrictness))}</td></tr>
            <tr><th>${e.sourceHtml("AI disclosure")}</th><td>${s(u(g.aiDisclosure))}</td></tr>
          </tbody>
        </table>
        <h3>${e.sourceHtml("Risk levels")}</h3>
        ${r.countTableHtml($.byLevel||{},"No unresolved quality risks.",A)}
        <h3>${e.sourceHtml("Quality categories")}</h3>
        ${r.qualityCategoryCountTableHtml($.byCategory||{},"No categorized quality risks.")}
      </section>
      <section>
        <h2>${e.sourceHtml("AI Triage")}</h2>
        <div class="cards">
          <div class="card"><strong>${d.drafts||0}</strong><span>${e.sourceHtml("AI initiated")}</span></div>
          <div class="card"><strong>${d.suggestionSegments||0}</strong><span>${e.sourceHtml("Segments with AI suggestions")}</span></div>
          <div class="card"><strong>${d.suggestions||0}</strong><span>${e.sourceHtml("AI suggestions")}</span></div>
          <div class="card"><strong>${d.reviewRisk||0}</strong><span>${e.sourceHtml("AI review risk")}</span></div>
          <div class="card"><strong>${d.highRisk||0}</strong><span>${e.sourceHtml("High AI risk")}</span></div>
        </div>
        <h3>${e.sourceHtml("AI review risk levels")}</h3>
        ${r.countTableHtml(d.risk||{},"No AI review risk recorded.")}
      </section>
      <section>
        <h2>${e.sourceHtml("Files")}</h2>
        <table>
          <thead><tr><th>${e.sourceHtml("File")}</th><th>${e.sourceHtml("Type")}</th><th>${e.sourceHtml("Segments")}</th><th>${e.sourceHtml("Words")}</th><th>${e.sourceHtml("Confirmed")}</th><th>${e.sourceHtml("Untranslated")}</th></tr></thead>
          <tbody>${R(v,o=>[`<td>${s(o.name)}</td>`,`<td>${s(o.type)}</td>`,`<td>${o.segments}</td>`,`<td>${o.words}</td>`,`<td>${o.confirmed}</td>`,`<td>${o.untranslated}</td>`])}</tbody>
        </table>
      </section>
      <section>
        <h2>${e.sourceHtml("Resources")}</h2>
        <div class="cards">
          <div class="card"><strong>${s(n?e.source("Redacted"):y.mainTm)}</strong><span>${e.sourceHtml("Main TM")}</span></div>
          <div class="card"><strong>${t.tmEntryCount}</strong><span>${e.sourceHtml("Linked TM units")}</span></div>
          <div class="card"><strong>${t.termCount}</strong><span>${e.sourceHtml("Linked terms")}</span></div>
          <div class="card"><strong>${t.forbiddenTermCount}</strong><span>${e.sourceHtml("Forbidden terms")}</span></div>
        </div>
        <p class="muted">${n?e.sourceHtml("Resource names are redacted."):`${e.sourceHtml("TMs")}: ${s(y.tmNames.join(", ")||e.source("None"))}`}</p>
        ${n?"":`<p class="muted">${e.sourceHtml("TBs")}: ${s(y.tbNames.join(", ")||e.source("None"))}</p>`}
      </section>
      <section>
        <h2>${e.sourceHtml("Terminology")}</h2>
        ${n?`<p class="muted">${e.sourceHtml("Terminology text is omitted from this anonymized report. Counts are preserved in Resources.")}</p>`:t.terms.length?`<table>
          <thead><tr><th>${e.sourceHtml("Source term")}</th><th>${e.sourceHtml("Target term")}</th><th>${e.sourceHtml("Status")}</th><th>${e.sourceHtml("Termbase")}</th><th>${e.sourceHtml("Notes")}</th></tr></thead>
          <tbody>${R(t.terms,o=>[`<td>${s(o.sourceTerm)}</td>`,`<td>${s(o.targetTerm)}</td>`,`<td>${e.sourceHtml(o.isForbidden?"Forbidden":"Approved")}</td>`,`<td>${s(r.safeLabel(o.termBaseName))}</td>`,`<td>${s(o.notes)}</td>`])}</tbody>
        </table>`:`<p class="muted">${e.sourceHtml("No linked terms.")}</p>`}
      </section>
      <section>
        <h2>${e.sourceHtml("QA Summary")}</h2>
        <h3>${e.sourceHtml("By severity")}</h3>
        ${r.countTableHtml(t.qaBySeverity)}
        <h3>${e.sourceHtml("By type")}</h3>
        ${r.countTableHtml(t.qaByType)}
        ${n?"":`<h3>${e.sourceHtml("QA details")}</h3>${r.qaChecksTableHtml(t.qaChecks)}`}
      </section>
      <section>
        <h2>${e.sourceHtml("Export Readiness")}</h2>
        ${r.countTableHtml(D,"None",I)}
        <h3>${e.sourceHtml("Risk and warnings")}</h3>
        ${r.listHtml([...i.risky,...i.warnings].map(L),"No risk or warning notes.")}
      </section>
      <section>
        <h2>${e.sourceHtml("Recent Activity")}</h2>
        ${n?r.countTableHtml(t.activityByType||{},"No activity recorded."):t.activityEvents.length?`<table><thead><tr><th>${e.sourceHtml("Time")}</th><th>${e.sourceHtml("Type")}</th><th>${e.sourceHtml("Summary")}</th></tr></thead><tbody>${R(t.activityEvents.slice(0,10),o=>[`<td>${s(f(o.createdAt))}</td>`,`<td>${s(e.source(o.type))}</td>`,`<td>${s(o.summary)}</td>`])}</tbody></table>`:`<p class="muted">${e.sourceHtml("No activity recorded.")}</p>`}
      </section>
      <footer>
        ${n?e.sourceHtml("This anonymized report contains counts without project names, file names, resource names, terminology text, activity summaries, or segment text."):e.sourceHtml("This report contains project metadata, counts, terminology, QA totals, and activity summaries. Segment text is not included.")}
      </footer>
    </main>
  </body>
</html>`}function B(t){let a=t.project,n=t.qualityPassport||{},c=b(n.profile||a.qualityProfile),l=n.riskQueue||{items:[],byLevel:{},totalRiskItems:0,highRiskCount:0,averageScore:0},d=k(t.validation)||{errors:[],risky:[],warnings:[],preserved:[],simplified:[],skipped:[],ok:!0},h=n.postEditingEffort||{label:"No segments",score:0,drivers:[]},g=(i,v)=>i.map(y=>`<tr>${v(y).join("")}</tr>`).join(""),$=r.safeLabel(a.name,e.source("Project")),H=(l.items||[]).slice(0,20);return`<!doctype html>
<html lang="${s(e.locale())}" dir="${s(e.direction())}">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; script-src 'none'; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'">
    <title>${s($)} - ${e.sourceHtml("LoopCAT Quality Passport")}</title>
    <style>${P}</style>
  </head>
  <body>
    <main>
      <header>
        <h1>${e.sourceHtml("LoopCAT Quality Passport")}</h1>
        <p>${s($)} - ${s(w(a.sourceLang,a.targetLang))}</p>
        <p class="muted">${e.sourceHtml("Generated {date}",{date:f(n.generatedAt||t.generatedAt)})}</p>
      </header>
      <section>
        ${n.exchangeRuns?.length?`<h2>LoopCAT Exchange — ${e.sourceHtml(n.exchangeIncomplete?"Incomplete":"Checks evaluated")}</h2><ul>${n.exchangeRuns.map(i=>`<li>${s(i.id)} ${s(i.version)}: ${e.sourceHtml(i.status)}</li>`).join("")}</ul>`:""}<h2>${e.sourceHtml("Quality Contract")}</h2>
        <table>
          <tbody>
            <tr><th>${e.sourceHtml("Standard")}</th><td>${s(u(c.standard))}</td></tr>
            <tr><th>${e.sourceHtml("Review depth")}</th><td>${s(u(c.reviewDepth))}</td></tr>
            <tr><th>${e.sourceHtml("Risk tolerance")}</th><td>${s(u(c.riskTolerance))}</td></tr>
            <tr><th>${e.sourceHtml("Terminology")}</th><td>${s(u(c.terminologyStrictness))}</td></tr>
            <tr><th>${e.sourceHtml("AI disclosure")}</th><td>${s(u(c.aiDisclosure))}</td></tr>
            <tr><th>${e.sourceHtml("Audience")}</th><td>${s(r.safeLabel(c.audience,e.source("Not set")))}</td></tr>
            <tr><th>${e.sourceHtml("Tone")}</th><td>${s(c.tone==="Neutral"?p("Neutral"):r.safeLabel(c.tone,p("Neutral")))}</td></tr>
          </tbody>
        </table>
      </section>
      <section>
        <h2>${e.sourceHtml("Delivery Evidence")}</h2>
        <div class="cards">
          <div class="card"><strong>${n.confidenceScore??0}</strong><span>${e.sourceHtml("Quality score")}</span></div>
          <div class="card"><strong>${s(e.source(h.label))}</strong><span>${e.sourceHtml("Post-editing effort")}</span></div>
          <div class="card"><strong>${l.totalRiskItems}</strong><span>${e.sourceHtml("Risk items")}</span></div>
          <div class="card"><strong>${l.highRiskCount}</strong><span>${e.sourceHtml("High risk")}</span></div>
          <div class="card"><strong>${t.qaChecks.length}</strong><span>${e.sourceHtml("QA issues")}</span></div>
          <div class="card"><strong>${t.analysis.totals.confirmedPercent}%</strong><span>${e.sourceHtml("Confirmed")}</span></div>
        </div>
      </section>
      <section>
        <h2>${e.sourceHtml("Risk Queue")}</h2>
        <h3>${e.sourceHtml("By level")}</h3>
        ${r.countTableHtml(l.byLevel||{},"No unresolved quality risks.",A)}
        <h3>${e.sourceHtml("Quality Categories")}</h3>
        ${r.qualityCategoryCountTableHtml(l.byCategory||{},"No categorized quality risks.")}
        <h3>${e.sourceHtml("Top risks")}</h3>
        ${H.length?`<table>
          <thead><tr><th>${e.sourceHtml("Segment")}</th><th>${e.sourceHtml("File")}</th><th>${e.sourceHtml("Category")}</th><th>${e.sourceHtml("Risk")}</th><th>${e.sourceHtml("Signals")}</th></tr></thead>
          <tbody>${g(H,i=>[`<td>#${s(i.label)}</td>`,`<td>${s(r.safeLabel(i.documentName,e.source("Document")))}</td>`,`<td>${s(N(i.category))}</td>`,`<td>${s(T(i.level))} ${i.score}</td>`,`<td>${s(i.reasons.map(v=>j(v,p,e.locale())).slice(0,3).join(" "))}</td>`])}</tbody>
        </table>`:`<p class="muted">${e.sourceHtml("No unresolved quality risks.")}</p>`}
      </section>
      <section>
        <h2>${e.sourceHtml("QA Evidence")}</h2>
        <h3>${e.sourceHtml("By severity")}</h3>
        ${r.countTableHtml(t.qaBySeverity)}
        <h3>${e.sourceHtml("By type")}</h3>
        ${r.countTableHtml(t.qaByType)}
        <h3>${e.sourceHtml("QA details")}</h3>
        ${r.qaChecksTableHtml(t.qaChecks)}
      </section>
      <section>
        <h2>${e.sourceHtml("Review And AI Evidence")}</h2>
        <div class="cards">
          <div class="card"><strong>${t.analysis.totals.comments}</strong><span>${e.sourceHtml("Review notes")}</span></div>
          <div class="card"><strong>${n.ai?.drafts||0}</strong><span>${e.sourceHtml("AI initiated")}</span></div>
          <div class="card"><strong>${n.ai?.reviewRisk||0}</strong><span>${e.sourceHtml("AI review risk")}</span></div>
          <div class="card"><strong>${n.ai?.highRisk||0}</strong><span>${e.sourceHtml("High AI risk")}</span></div>
          <div class="card"><strong>${t.tmEntryCount}</strong><span>${e.sourceHtml("Linked TM units")}</span></div>
          <div class="card"><strong>${t.termCount}</strong><span>${e.sourceHtml("Linked terms")}</span></div>
        </div>
        <h3>${e.sourceHtml("Review states")}</h3>
        ${r.countTableHtml(n.reviewByState||{},"No review states recorded.",Q)}
      </section>
      <section>
        <h2>${e.sourceHtml("Export Readiness")}</h2>
        <div class="cards">
          <div class="card"><strong>${d.errors.length}</strong><span>${e.sourceHtml("Errors")}</span></div>
          <div class="card"><strong>${d.risky.length}</strong><span>${e.sourceHtml("Risks")}</span></div>
          <div class="card"><strong>${d.warnings.length}</strong><span>${e.sourceHtml("Warnings")}</span></div>
        </div>
        ${r.listHtml([...d.errors,...d.risky,...d.warnings].map(L),"No export-readiness findings.")}
      </section>
      <section>
        <h2>${e.sourceHtml("Effort Drivers")}</h2>
        ${r.listHtml((h.drivers||[]).map(z),"No major post-editing drivers.")}
      </section>
      <footer>
        ${e.sourceHtml("This passport contains quality settings, counts, risk signals, and readiness evidence. Segment text is not included.")}
      </footer>
    </main>
  </body>
</html>`}return Object.freeze({projectReportHtml:E,qualityPassportHtml:B})}export{U as createReportDocumentCompositionService};
