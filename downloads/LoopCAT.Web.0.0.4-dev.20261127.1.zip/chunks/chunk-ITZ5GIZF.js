var t=new WeakSet;function o(e,n){return n?t.add(e):t.delete(e),e}function r(e){return t.has(e)}export{o as a,r as b};
