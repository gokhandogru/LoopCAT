function P(d){let t=d?.localization,o=d?.presentation,e=d?.escapeHtml,R=d?.redactSensitiveText,H=d?.defaultQualityProfile,b=d?.sanitizeValidationReportForDisplay,k=d?.languagePairDisplay,f=d?.formatDateTime,m=d?.qualityLabel,w=d?.qualityCategoryName,C=d?.qualityRiskLevelLabel;if(typeof t?.source!="function"||typeof t?.sourceHtml!="function"||typeof t?.locale!="function"||typeof t?.direction!="function"||typeof o?.countTableHtml!="function"||typeof o?.listHtml!="function"||typeof o?.qaChecksTableHtml!="function"||typeof o?.qualityCategoryCountTableHtml!="function"||typeof o?.safeLabel!="function"||typeof e!="function"||typeof R!="function"||typeof H!="function"||typeof b!="function"||typeof k!="function"||typeof f!="function"||typeof m!="function"||typeof w!="function"||typeof C!="function")throw new TypeError("ReportDocumentCompositionService requires localization, presentation, escaping, redaction, quality, validation, language, and date boundaries.");function L(s,h={}){let n=!!h.anonymized,c=s.project,a=s.analysis.totals,l=s.analysis.ai||{drafts:0,suggestionSegments:0,suggestions:0,reviewRisk:0,highRisk:0,risk:{}},u=s.qualityPassport||{},p=H(u.profile||c.qualityProfile),g=u.riskQueue||{totalRiskItems:0,highRiskCount:0,averageScore:0,byLevel:{}},y=u.postEditingEffort||{label:"No segments",score:0,drivers:[]},i=b(s.validation)||{errors:[],risky:[],warnings:[],preserved:[],simplified:[],skipped:[],ok:!0},$=n?s.analysis.files.map((r,T)=>({...r,name:`File ${T+1}`})):s.analysis.files.map(r=>({...r,name:o.safeLabel(r.name,"File")})),v=n?s.resources:{...s.resources,mainTm:o.safeLabel(s.resources.mainTm,"None"),tmNames:(s.resources.tmNames||[]).map(r=>o.safeLabel(r)).filter(Boolean),tbNames:(s.resources.tbNames||[]).map(r=>o.safeLabel(r)).filter(Boolean)},N={errors:i.errors.length,risk:i.risky.length,warnings:i.warnings.length,notes:i.preserved.length+i.simplified.length+i.skipped.length},x=(r,T)=>r.map(j=>`<tr>${T(j).join("")}</tr>`).join(""),q=n?t.source("Anonymized project"):o.safeLabel(c.name,t.source("Project")),A=n?t.source("LoopCAT Anonymized Project Report"):t.source("LoopCAT Project Report");return`<!doctype html>
<html lang="${e(t.locale())}" dir="${e(t.direction())}">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; script-src 'none'; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'">
    <title>${e(q)} - ${e(A)}</title>
    <style>
      :root { color-scheme: light; font-family: Arial, sans-serif; color: #1f2937; background: #f6f8fa; }
      body { margin: 0; padding: 32px; }
      main { max-width: 980px; margin: 0 auto; background: #fff; border: 1px solid #d9e0e7; border-radius: 8px; overflow: hidden; }
      header { padding: 28px 32px; background: #202936; color: #fff; }
      h1, h2, h3, p { margin-top: 0; }
      h1 { font-size: 26px; margin-bottom: 8px; }
      h2 { font-size: 18px; margin-bottom: 12px; }
      section { padding: 24px 32px; border-top: 1px solid #e5eaf0; }
      .meta, .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; }
      .card { border: 1px solid #d9e0e7; border-radius: 8px; padding: 14px; background: #fbfcfd; }
      .card strong { display: block; font-size: 22px; margin-bottom: 4px; }
      .muted { color: #657386; }
      table { width: 100%; border-collapse: collapse; font-size: 14px; }
      th, td { border-bottom: 1px solid #e5eaf0; padding: 9px 8px; text-align: left; vertical-align: top; }
      th { color: #405064; background: #f4f7f9; }
      ul { margin: 0; padding-left: 20px; }
      footer { padding: 18px 32px; color: #657386; font-size: 12px; border-top: 1px solid #e5eaf0; }
    </style>
  </head>
  <body>
    <main>
      <header>
        <h1>${e(A)}</h1>
        <p>${e(q)} - ${e(k(c.sourceLang,c.targetLang))}</p>
        <p class="muted">${t.sourceHtml("Generated {date}",{date:f(s.generatedAt)})}</p>
      </header>
      <section>
        <h2>${t.sourceHtml("Project")}</h2>
        <div class="meta">
          <div class="card"><strong>${e(R(c.domain||"").trim()||t.source("Not set"))}</strong><span>${t.sourceHtml("Domain")}</span></div>
          <div class="card"><strong>${a.confirmedPercent}%</strong><span>${t.sourceHtml("Confirmed")}</span></div>
          <div class="card"><strong>${a.words}</strong><span>${t.sourceHtml("Source words")}</span></div>
          <div class="card"><strong>${s.qaChecks.length}</strong><span>${t.sourceHtml("QA issues")}</span></div>
        </div>
      </section>
      <section>
        <h2>${t.sourceHtml("Progress")}</h2>
        <div class="cards">
          <div class="card"><strong>${a.files}</strong><span>${t.sourceHtml("Files")}</span></div>
          <div class="card"><strong>${a.segments}</strong><span>${t.sourceHtml("Segments")}</span></div>
          <div class="card"><strong>${a.confirmed}</strong><span>${t.sourceHtml("Confirmed")}</span></div>
          <div class="card"><strong>${a.untranslated}</strong><span>${t.sourceHtml("Untranslated")}</span></div>
          <div class="card"><strong>${a.repetitions}</strong><span>${t.sourceHtml("Repetitions")}</span></div>
          <div class="card"><strong>${a.comments}</strong><span>${t.sourceHtml("Review notes")}</span></div>
          <div class="card"><strong>${s.revisionCount}</strong><span>${t.sourceHtml("Target revisions")}</span></div>
        </div>
      </section>
      <section>
        <h2>${t.sourceHtml("Quality Passport")}</h2>
        <div class="cards">
          <div class="card"><strong>${u.confidenceScore??0}</strong><span>${t.sourceHtml("Quality score")}</span></div>
          <div class="card"><strong>${e(t.source(y.label))}</strong><span>${t.sourceHtml("Post-editing effort")}</span></div>
          <div class="card"><strong>${g.totalRiskItems}</strong><span>${t.sourceHtml("Risk items")}</span></div>
          <div class="card"><strong>${g.highRiskCount}</strong><span>${t.sourceHtml("High risk")}</span></div>
        </div>
        <table>
          <tbody>
            <tr><th>${t.sourceHtml("Standard")}</th><td>${e(m(p.standard))}</td></tr>
            <tr><th>${t.sourceHtml("Review depth")}</th><td>${e(m(p.reviewDepth))}</td></tr>
            <tr><th>${t.sourceHtml("Risk tolerance")}</th><td>${e(m(p.riskTolerance))}</td></tr>
            <tr><th>${t.sourceHtml("Terminology")}</th><td>${e(m(p.terminologyStrictness))}</td></tr>
            <tr><th>${t.sourceHtml("AI disclosure")}</th><td>${e(m(p.aiDisclosure))}</td></tr>
          </tbody>
        </table>
        <h3>${t.sourceHtml("Risk levels")}</h3>
        ${o.countTableHtml(g.byLevel||{},"No unresolved quality risks.")}
        <h3>${t.sourceHtml("Quality categories")}</h3>
        ${o.qualityCategoryCountTableHtml(g.byCategory||{},"No categorized quality risks.")}
      </section>
      <section>
        <h2>${t.sourceHtml("AI Triage")}</h2>
        <div class="cards">
          <div class="card"><strong>${l.drafts||0}</strong><span>${t.sourceHtml("AI initiated")}</span></div>
          <div class="card"><strong>${l.suggestionSegments||0}</strong><span>${t.sourceHtml("Segments with AI suggestions")}</span></div>
          <div class="card"><strong>${l.suggestions||0}</strong><span>${t.sourceHtml("AI suggestions")}</span></div>
          <div class="card"><strong>${l.reviewRisk||0}</strong><span>${t.sourceHtml("AI review risk")}</span></div>
          <div class="card"><strong>${l.highRisk||0}</strong><span>${t.sourceHtml("High AI risk")}</span></div>
        </div>
        <h3>${t.sourceHtml("AI review risk levels")}</h3>
        ${o.countTableHtml(l.risk||{},"No AI review risk recorded.")}
      </section>
      <section>
        <h2>${t.sourceHtml("Files")}</h2>
        <table>
          <thead><tr><th>${t.sourceHtml("File")}</th><th>${t.sourceHtml("Type")}</th><th>${t.sourceHtml("Segments")}</th><th>${t.sourceHtml("Words")}</th><th>${t.sourceHtml("Confirmed")}</th><th>${t.sourceHtml("Untranslated")}</th></tr></thead>
          <tbody>${x($,r=>[`<td>${e(r.name)}</td>`,`<td>${e(r.type)}</td>`,`<td>${r.segments}</td>`,`<td>${r.words}</td>`,`<td>${r.confirmed}</td>`,`<td>${r.untranslated}</td>`])}</tbody>
        </table>
      </section>
      <section>
        <h2>${t.sourceHtml("Resources")}</h2>
        <div class="cards">
          <div class="card"><strong>${e(n?t.source("Redacted"):v.mainTm)}</strong><span>${t.sourceHtml("Main TM")}</span></div>
          <div class="card"><strong>${s.tmEntryCount}</strong><span>${t.sourceHtml("Linked TM units")}</span></div>
          <div class="card"><strong>${s.termCount}</strong><span>${t.sourceHtml("Linked terms")}</span></div>
          <div class="card"><strong>${s.forbiddenTermCount}</strong><span>${t.sourceHtml("Forbidden terms")}</span></div>
        </div>
        <p class="muted">${n?t.sourceHtml("Resource names are redacted."):`${t.sourceHtml("TMs")}: ${e(v.tmNames.join(", ")||t.source("None"))}`}</p>
        ${n?"":`<p class="muted">${t.sourceHtml("TBs")}: ${e(v.tbNames.join(", ")||t.source("None"))}</p>`}
      </section>
      <section>
        <h2>${t.sourceHtml("Terminology")}</h2>
        ${n?`<p class="muted">${t.sourceHtml("Terminology text is omitted from this anonymized report. Counts are preserved in Resources.")}</p>`:s.terms.length?`<table>
          <thead><tr><th>${t.sourceHtml("Source term")}</th><th>${t.sourceHtml("Target term")}</th><th>${t.sourceHtml("Status")}</th><th>${t.sourceHtml("Termbase")}</th><th>${t.sourceHtml("Notes")}</th></tr></thead>
          <tbody>${x(s.terms,r=>[`<td>${e(r.sourceTerm)}</td>`,`<td>${e(r.targetTerm)}</td>`,`<td>${t.sourceHtml(r.isForbidden?"Forbidden":"Approved")}</td>`,`<td>${e(o.safeLabel(r.termBaseName))}</td>`,`<td>${e(r.notes)}</td>`])}</tbody>
        </table>`:`<p class="muted">${t.sourceHtml("No linked terms.")}</p>`}
      </section>
      <section>
        <h2>${t.sourceHtml("QA Summary")}</h2>
        <h3>${t.sourceHtml("By severity")}</h3>
        ${o.countTableHtml(s.qaBySeverity)}
        <h3>${t.sourceHtml("By type")}</h3>
        ${o.countTableHtml(s.qaByType)}
        ${n?"":`<h3>${t.sourceHtml("QA details")}</h3>${o.qaChecksTableHtml(s.qaChecks)}`}
      </section>
      <section>
        <h2>${t.sourceHtml("Export Readiness")}</h2>
        ${o.countTableHtml(N)}
        <h3>${t.sourceHtml("Risk and warnings")}</h3>
        ${o.listHtml([...i.risky,...i.warnings],"No risk or warning notes.")}
      </section>
      <section>
        <h2>${t.sourceHtml("Recent Activity")}</h2>
        ${n?o.countTableHtml(s.activityByType||{},"No activity recorded."):s.activityEvents.length?`<table><thead><tr><th>${t.sourceHtml("Time")}</th><th>${t.sourceHtml("Type")}</th><th>${t.sourceHtml("Summary")}</th></tr></thead><tbody>${x(s.activityEvents.slice(0,10),r=>[`<td>${e(f(r.createdAt))}</td>`,`<td>${e(t.source(r.type))}</td>`,`<td>${e(r.summary)}</td>`])}</tbody></table>`:`<p class="muted">${t.sourceHtml("No activity recorded.")}</p>`}
      </section>
      <footer>
        ${n?t.sourceHtml("This anonymized report contains counts without project names, file names, resource names, terminology text, activity summaries, or segment text."):t.sourceHtml("This report contains project metadata, counts, terminology, QA totals, and activity summaries. Segment text is not included.")}
      </footer>
    </main>
  </body>
</html>`}function S(s){let h=s.project,n=s.qualityPassport||{},c=H(n.profile||h.qualityProfile),a=n.riskQueue||{items:[],byLevel:{},totalRiskItems:0,highRiskCount:0,averageScore:0},l=b(s.validation)||{errors:[],risky:[],warnings:[],preserved:[],simplified:[],skipped:[],ok:!0},u=n.postEditingEffort||{label:"No segments",score:0,drivers:[]},p=(i,$)=>i.map(v=>`<tr>${$(v).join("")}</tr>`).join(""),g=o.safeLabel(h.name,t.source("Project")),y=(a.items||[]).slice(0,20);return`<!doctype html>
<html lang="${e(t.locale())}" dir="${e(t.direction())}">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; script-src 'none'; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'">
    <title>${e(g)} - ${t.sourceHtml("LoopCAT Quality Passport")}</title>
    <style>
      :root { color-scheme: light; font-family: Arial, sans-serif; color: #1f2937; background: #f6f8fa; }
      body { margin: 0; padding: 32px; }
      main { max-width: 980px; margin: 0 auto; background: #fff; border: 1px solid #d9e0e7; border-radius: 8px; overflow: hidden; }
      header { padding: 28px 32px; background: #202936; color: #fff; }
      h1, h2, h3, p { margin-top: 0; }
      h1 { font-size: 26px; margin-bottom: 8px; }
      h2 { font-size: 18px; margin-bottom: 12px; }
      section { padding: 24px 32px; border-top: 1px solid #e5eaf0; }
      .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px; }
      .card { border: 1px solid #d9e0e7; border-radius: 8px; padding: 14px; background: #fbfcfd; }
      .card strong { display: block; font-size: 22px; margin-bottom: 4px; }
      .muted { color: #657386; }
      table { width: 100%; border-collapse: collapse; font-size: 14px; }
      th, td { border-bottom: 1px solid #e5eaf0; padding: 9px 8px; text-align: left; vertical-align: top; }
      th { color: #405064; background: #f4f7f9; }
      ul { margin: 0; padding-left: 20px; }
      footer { padding: 18px 32px; color: #657386; font-size: 12px; border-top: 1px solid #e5eaf0; }
    </style>
  </head>
  <body>
    <main>
      <header>
        <h1>${t.sourceHtml("LoopCAT Quality Passport")}</h1>
        <p>${e(g)} - ${e(k(h.sourceLang,h.targetLang))}</p>
        <p class="muted">${t.sourceHtml("Generated {date}",{date:f(n.generatedAt||s.generatedAt)})}</p>
      </header>
      <section>
        <h2>${t.sourceHtml("Quality Contract")}</h2>
        <table>
          <tbody>
            <tr><th>${t.sourceHtml("Standard")}</th><td>${e(m(c.standard))}</td></tr>
            <tr><th>${t.sourceHtml("Review depth")}</th><td>${e(m(c.reviewDepth))}</td></tr>
            <tr><th>${t.sourceHtml("Risk tolerance")}</th><td>${e(m(c.riskTolerance))}</td></tr>
            <tr><th>${t.sourceHtml("Terminology")}</th><td>${e(m(c.terminologyStrictness))}</td></tr>
            <tr><th>${t.sourceHtml("AI disclosure")}</th><td>${e(m(c.aiDisclosure))}</td></tr>
            <tr><th>${t.sourceHtml("Audience")}</th><td>${e(o.safeLabel(c.audience,t.source("Not set")))}</td></tr>
            <tr><th>${t.sourceHtml("Tone")}</th><td>${e(o.safeLabel(c.tone,t.source("Neutral")))}</td></tr>
          </tbody>
        </table>
      </section>
      <section>
        <h2>${t.sourceHtml("Delivery Evidence")}</h2>
        <div class="cards">
          <div class="card"><strong>${n.confidenceScore??0}</strong><span>${t.sourceHtml("Quality score")}</span></div>
          <div class="card"><strong>${e(t.source(u.label))}</strong><span>${t.sourceHtml("Post-editing effort")}</span></div>
          <div class="card"><strong>${a.totalRiskItems}</strong><span>${t.sourceHtml("Risk items")}</span></div>
          <div class="card"><strong>${a.highRiskCount}</strong><span>${t.sourceHtml("High risk")}</span></div>
          <div class="card"><strong>${s.qaChecks.length}</strong><span>${t.sourceHtml("QA issues")}</span></div>
          <div class="card"><strong>${s.analysis.totals.confirmedPercent}%</strong><span>${t.sourceHtml("Confirmed")}</span></div>
        </div>
      </section>
      <section>
        <h2>${t.sourceHtml("Risk Queue")}</h2>
        <h3>${t.sourceHtml("By level")}</h3>
        ${o.countTableHtml(a.byLevel||{},"No unresolved quality risks.")}
        <h3>${t.sourceHtml("Quality Categories")}</h3>
        ${o.qualityCategoryCountTableHtml(a.byCategory||{},"No categorized quality risks.")}
        <h3>${t.sourceHtml("Top risks")}</h3>
        ${y.length?`<table>
          <thead><tr><th>${t.sourceHtml("Segment")}</th><th>${t.sourceHtml("File")}</th><th>${t.sourceHtml("Category")}</th><th>${t.sourceHtml("Risk")}</th><th>${t.sourceHtml("Signals")}</th></tr></thead>
          <tbody>${p(y,i=>[`<td>#${e(i.label)}</td>`,`<td>${e(o.safeLabel(i.documentName,t.source("Document")))}</td>`,`<td>${e(w(i.category))}</td>`,`<td>${e(C(i.level))} ${i.score}</td>`,`<td>${e(i.reasons.map($=>$.label).slice(0,3).join(" "))}</td>`])}</tbody>
        </table>`:`<p class="muted">${t.sourceHtml("No unresolved quality risks.")}</p>`}
      </section>
      <section>
        <h2>${t.sourceHtml("QA Evidence")}</h2>
        <h3>${t.sourceHtml("By severity")}</h3>
        ${o.countTableHtml(s.qaBySeverity)}
        <h3>${t.sourceHtml("By type")}</h3>
        ${o.countTableHtml(s.qaByType)}
        <h3>${t.sourceHtml("QA details")}</h3>
        ${o.qaChecksTableHtml(s.qaChecks)}
      </section>
      <section>
        <h2>${t.sourceHtml("Review And AI Evidence")}</h2>
        <div class="cards">
          <div class="card"><strong>${s.analysis.totals.comments}</strong><span>${t.sourceHtml("Review notes")}</span></div>
          <div class="card"><strong>${n.ai?.drafts||0}</strong><span>${t.sourceHtml("AI initiated")}</span></div>
          <div class="card"><strong>${n.ai?.reviewRisk||0}</strong><span>${t.sourceHtml("AI review risk")}</span></div>
          <div class="card"><strong>${n.ai?.highRisk||0}</strong><span>${t.sourceHtml("High AI risk")}</span></div>
          <div class="card"><strong>${s.tmEntryCount}</strong><span>${t.sourceHtml("Linked TM units")}</span></div>
          <div class="card"><strong>${s.termCount}</strong><span>${t.sourceHtml("Linked terms")}</span></div>
        </div>
        <h3>${t.sourceHtml("Review states")}</h3>
        ${o.countTableHtml(n.reviewByState||{},"No review states recorded.")}
      </section>
      <section>
        <h2>${t.sourceHtml("Export Readiness")}</h2>
        <div class="cards">
          <div class="card"><strong>${l.errors.length}</strong><span>${t.sourceHtml("Errors")}</span></div>
          <div class="card"><strong>${l.risky.length}</strong><span>${t.sourceHtml("Risks")}</span></div>
          <div class="card"><strong>${l.warnings.length}</strong><span>${t.sourceHtml("Warnings")}</span></div>
        </div>
        ${o.listHtml([...l.errors,...l.risky,...l.warnings],"No export-readiness findings.")}
      </section>
      <section>
        <h2>${t.sourceHtml("Effort Drivers")}</h2>
        ${o.listHtml(u.drivers||[],"No major post-editing drivers.")}
      </section>
      <footer>
        ${t.sourceHtml("This passport contains quality settings, counts, risk signals, and readiness evidence. Segment text is not included.")}
      </footer>
    </main>
  </body>
</html>`}return Object.freeze({projectReportHtml:L,qualityPassportHtml:S})}export{P as createReportDocumentCompositionService};
